Before running app 
Run cmd - go mod tidy
//It will download all necessory packages