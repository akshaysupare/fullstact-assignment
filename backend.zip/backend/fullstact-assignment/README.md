# fullstact-assignment
1. Develop a LRU cache with Get/Set API 2. Build a react app that consumes the LRU cache api
